from SSD.MBs.pyBN.classes.cliquetree import CliqueTree, Clique
