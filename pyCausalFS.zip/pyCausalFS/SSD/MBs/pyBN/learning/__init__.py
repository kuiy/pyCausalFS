from SSD.MBs.pyBN.learning.parameter import *
from SSD.MBs.pyBN.learning.structure import *