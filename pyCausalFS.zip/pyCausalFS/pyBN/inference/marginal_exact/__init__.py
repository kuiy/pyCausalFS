from pyBN.inference.marginal_exact.exact_bp import *
from pyBN.inference.marginal_exact.ve_marginal import *