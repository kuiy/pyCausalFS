from pyBN.inference.map_exact import *
from pyBN.inference.marginal_approx import *
from pyBN.inference.marginal_exact import *