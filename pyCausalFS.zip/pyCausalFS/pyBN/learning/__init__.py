from pyBN.learning.parameter import *
from pyBN.learning.structure import *