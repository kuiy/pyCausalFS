from pyBN.learning.parameter.bayes import *
from pyBN.learning.parameter.mle import *