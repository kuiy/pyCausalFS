from pyBN.learning.structure.naive.naive_bayes import *
from pyBN.learning.structure.naive.TAN import *